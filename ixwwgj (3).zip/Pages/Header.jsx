import React from "react";
import image from "./images-removebg-preview (1).png"
import classes from './Head.module.css'

const Header = () => {
  return (
      <div className={classes.Huy}>
        <div className={classes.Head}>
          <div><img className={classes.Hdst} src={image} alt={'logo'}/></div>
          <div> <a href="">Все про нас</a></div>
          <div> <a href="">Послуги</a></div>
          <div> <a href="">Ціни</a></div>
          <div> <a href="">Контакти</a></div>
          <div> <a href="">Адреса</a></div>

        </div>
      </div> 
  )
}

export default Header;