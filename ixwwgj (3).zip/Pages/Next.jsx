import React from "react";
import images from "./images-removebg-preview (1).png"
import classes from "./Next.module.css";

const Next = () => {
  return (
    <div className={classes.Next}>
             <div className="col-md-8 products">
                <div className="row">
                    <div className="col-sm-4">
                        <div className="product">
                            <div className="product-img">
                                <a href="#"><img className="img" src={images} alt={'hggg'}/></a>
                            </div>
                            <p className="product-title">
                                <a href="#">Cream jane jeans dress</a>
                            </p>
                            <p className="product-desc">Signature NYX cosmetics</p>
                            <p className="product-price">Price: €10.00</p>
                        </div>                       
                    </div>
              
                </div>
            </div>
        </div>
  );
};

export default Next;