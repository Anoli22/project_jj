import "./styles.css";
import Section from "../Pages/Section"
import Header from "../Pages/Header"
import Next from "../Pages/Next"

export default function App() {
  return (
    <div className="App">
      <Header/>
      <Section/>
        <div className="List">
         <div> <Next/> </div>
         <div> <Next/> </div>
         <div> <Next/> </div>
         <div> <Next/> </div>
        </div>
    </div>
  );
};